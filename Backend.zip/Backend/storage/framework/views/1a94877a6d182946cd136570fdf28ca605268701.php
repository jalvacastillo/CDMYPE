<?php $__env->startSection('titulo'); ?>
  Sobre Nosotros
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('nosotros.title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="content">
        <div class="container">
            <div class="page-content">


            <?php echo $__env->make('nosotros.intro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="hr5" style="margin:50px 0px;"></div>

            <?php echo $__env->make('nosotros.misionvision', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="hr5" style="margin:50px 0px;"></div>

            <?php echo $__env->make('nosotros.equipo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
            


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>