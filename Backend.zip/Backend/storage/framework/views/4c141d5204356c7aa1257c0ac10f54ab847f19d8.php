<?php $__env->startSection('titulo'); ?>
  Pasantias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('pasantias.title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="content">
          <div class="container">
            <div class="page-content">


                <div class="row list-group">
                
                <?php $__currentLoopData = $pasantias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasantia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" class="list-group-item">
                        <div class="media col-sm-3 hidden-xs">
                          <figure class="pull-left">
                              <img class="media-object img-rounded img-responsive"  src="http://placehold.it/350x250" alt="" >
                          </figure>
                        </div>
                        <div class="col-sm-6">
                          <h2 class="list-group-item-heading"> <?php echo e($pasantia->titulo); ?> </h2>
                          <p class="label label-info"><?php echo e($pasantia->tipo); ?></p>
                          <p class="label label-success"><?php echo e($pasantia->especialidad); ?></p>
                          <p class="list-group-item-text"> <?php echo e($pasantia->descripcion); ?> </p>
                        </div>
                        <div class="col-sm-3 text-center">
                          <h4> <?php echo e($pasantia->finalizacion); ?> <br><small>Fecha límite</small></h4>
                          
                          <h4> <?php echo e($pasantia->duracion); ?> <br><small>Duración</small></h4>
                          
                          
                          <button type="button" class="btn btn-primary btn-block"> Aplicar </button>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
              <div class="text-center">
                <?php echo e($pasantias->links()); ?>

              </div>

            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>