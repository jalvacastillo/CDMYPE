<?php $__env->startSection('titulo'); ?>
  Contactos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('contactos.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="content">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('contactos.contactos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('contactos.informacion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>