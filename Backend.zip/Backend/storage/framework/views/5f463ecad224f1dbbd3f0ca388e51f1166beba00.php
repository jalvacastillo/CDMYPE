<h2>Hola</h2>
<h4>Te ha escrito:</h4>
<hr>
<p><b>Nombre: </b><?php echo e($msj['nombre']); ?></p>
<p><b>Correo: </b><a href="mailto:<?php echo e($msj['correo']); ?>"><?php echo e($msj['correo']); ?></a></p>
<p><b>Mensaje: </b><?php echo e($msj['mensaje']); ?></p>