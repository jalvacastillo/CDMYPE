<?php $__env->startSection('titulo'); ?>
  Noticias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('noticias.title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="content">
        <div class="container">
            <div class="row blog-page">

                <div class="col-md-9 blog-box">

                    <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($noticia->categoria == 'Imagen'): ?>

                        <div class="blog-post image-post">
                          <!-- Post Thumb -->
                          <div class="post-head">
                            <a class="lightbox" title="<?php echo e($noticia->titulo); ?>" href="assets/images/<?php echo e($noticia->recurso); ?>">
                              <div class="thumb-overlay"><i class="fa fa-arrows-alt"></i></div>
                              <img alt="" src="assets/images/<?php echo e($noticia->recurso); ?>">
                            </a>
                          </div>
                          <!-- Post Content -->
                          <div class="post-content">
                            <div class="post-type"><i class="fa fa-picture-o"></i></div>
                            <h2><a href="#"><?php echo e($noticia->titulo); ?></a></h2>
                            <ul class="post-meta">
                              <li>Autor: <a href="#"><?php echo e($noticia->asesor); ?></a></li>
                              <li><?php echo e($noticia->created_at); ?></li>
                              <li><a href="#"><?php echo e($noticia->tipo); ?></a></li>
                            </ul>
                            <p><?php echo e($noticia->descripcion); ?></p>
                            <a class="main-button" href="#">Leer más <i class="fa fa-angle-right"></i></a>
                          </div>
                        </div>

                        <?php elseif($noticia->categoria == 'Video'): ?>

                        <div class="blog-post video-post">
                          <!-- Post Video -->
                          <div class="post-head">
                          <iframe width="560" height="315" src="" frameborder="0" allowfullscreen></iframe>
                          </div>
                          <!-- Post Content -->
                          <div class="post-content">
                            <div class="post-type"><i class="fa fa-play"></i></div>
                            <h2><a href="#"><?php echo e($noticia->titulo); ?></a></h2>
                            <ul class="post-meta">
                              <li>Autor: <a href="#"><?php echo e($noticia->asesor); ?></a></li>
                              <li><?php echo e($noticia->created_at); ?></li>
                              <li><a href="#"><?php echo e($noticia->tipo); ?></a></li>
                            </ul>
                            <p><?php echo e($noticia->descripcion); ?></p>
                            <a class="main-button" href="#">Leer más <i class="fa fa-angle-right"></i></a>
                          </div>
                        </div>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="text-center">
                    <?php echo e($noticias->links()); ?>

                  </div>

                </div>


              <?php echo $__env->make('noticias.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>