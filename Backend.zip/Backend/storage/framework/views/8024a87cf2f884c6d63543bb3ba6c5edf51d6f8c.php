<!doctype html>
<html lang="es">
<head>

  <!-- Basic -->
  <title>CDMYPE - <?php echo $__env->yieldContent('titulo', 'Bienvenido'); ?></title>

  <!-- Define Charset -->
  <meta charset="utf-8">

  <!-- Responsive Metatag -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- Page Description and Author -->
  <meta name="description" content="Somos un Centro de Desarrollo de la Micro y Pequeña Empresa que atiende cabañas y cuscatlán.">
  <meta name="author" content="Jesus Alvarado - Asesor TIC">

  <!-- Bootstrap CSS  -->
  <link rel="stylesheet" href="assets/css/bootstrap.css" type="text/css" media="screen">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css" media="screen">

  <!-- Slicknav -->
  <link rel="stylesheet" type="text/css" href="assets/css/slicknav.css" media="screen">

  <!-- Margo CSS Styles  -->
  <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="screen">

  <!-- Responsive CSS Styles  -->
  <link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="screen">

  <!-- Css3 Transitions Styles  -->
  <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">

  <!-- Color CSS Styles  -->
  <link rel="stylesheet" type="text/css" href="assets/css/colors/blue.css" title="blue" media="screen" />

  <!-- Margo JS  -->
  <script type="text/javascript" src="assets/js/jquery-2.1.4.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.migrate.js"></script>
  <script type="text/javascript" src="assets/js/modernizrr.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.fitvids.js"></script>
  <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
  <script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.isotope.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.appear.js"></script>
  <script type="text/javascript" src="assets/js/count-to.js"></script>
  <script type="text/javascript" src="assets/js/jquery.textillate.js"></script>
  <script type="text/javascript" src="assets/js/jquery.lettering.js"></script>
  <script type="text/javascript" src="assets/js/jquery.easypiechart.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.nicescroll.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.parallax.js"></script>
  <script type="text/javascript" src="assets/js/mediaelement-and-player.js"></script>
  <script type="text/javascript" src="assets/js/jquery.slicknav.js"></script>
  

  <!--[if IE 8]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>

<body>
    <div id="container">

        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="alert alert-warning" style="position: absolute; right: 0; left: 0; width: 210px; margin: 10px auto; z-index: 999999999;">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          Página en <strong>construcción.</strong>
        </div>
        
        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  </div>


  <!-- Go To Top Link -->
  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <div id="loader">
    <div class="spinner">
      <div class="dot1"></div>
      <div class="dot2"></div>
    </div>
  </div>

  

  <script type="text/javascript" src="assets/js/script.js"></script>

</body>

</html>