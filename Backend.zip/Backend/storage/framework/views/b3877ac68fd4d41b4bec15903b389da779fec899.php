<h4 class="classic-title"><span>Asesorías</span></h4>

<div class="row">

  <div class="col-sm-6 col-md-3 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-01.jpg" alt="" />
    <h4>Asesorías Empresariales</h4>
    <p>Brindamos apoyo y acompañamiento para la correcta administración y gestión de tu empresa.</p>
  </div>

  <div class="col-sm-6 col-md-3 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-02.jpg" alt="" />
    <h4>Asesorías Financieras</h4>
    <p>Ofrecemos ayuda para la adquisición de créditos y prestamos, asi como la asesoría en el manejo de tus finanzas.</p>
  </div>

  <div class="col-sm-6 col-md-3 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-03.jpg" alt="" />
    <h4>Asesorías TIC</h4>
    <p>Ayudamos a aplicar la tecnología en su empresa, le capacitamos y asesoramos en todo lo relacionado con las TIC´s.</p>
  </div>

  <div class="col-sm-6 col-md-3 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-03.jpg" alt="" />
    <h4>Asesorías EFE</h4>
    <p>Contamos con perosanal especializado para apoyar las empresas que son lideradas por mujeres.</p>
  </div>

  </div>

<h4 class="classic-title"><span>Otros</span></h4>

<div class="row">

  <div class="col-sm-6 col-md-4 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-01.jpg" alt="" />
    <h4>Capacitaciones</h4>
    <p>Brindamos formación en diferentes áreas de manera grupal para una o varias empresas en temas empresariales.</p>
  </div>

  <div class="col-sm-6 col-md-4 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-02.jpg" alt="" />
    <h4>Asistencia Técnica</h4>
    <p>Apoyamos de forma técnica y especializada con la contratación de consultores especializados.</p>
  </div>

  <div class="col-sm-6 col-md-4 image-service-box">
    <img class="img-thumbnail" src="assets/images/service-03.jpg" alt="" />
    <h4>Vinculación</h4>
    <p>Facilitamos a las empresas el acercamiento a programas y/o servicios de otras institucíones, tambien a crear alianzas comerciales con otras empresas.</p>
  </div>

</div>