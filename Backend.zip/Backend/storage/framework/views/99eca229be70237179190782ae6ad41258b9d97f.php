<?php $__env->startSection('titulo'); ?>
  Clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('clientes.title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <!-- Start Content -->
        <div id="content">
          <div class="container">
            <div class="page-content">


              <div class="row">

                  
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="thumbnail">
                          <img src="http://placehold.it/350x250" alt="...">
                          <div class="caption">
                            <h3><?php echo e($cliente->empresa()->first()->nombre); ?></h3>
                            <p class="label label-primary"><?php echo e($cliente->empresa()->first()->sector); ?></p>
                          </div>
                          <div class="panel-footer">
                            <p><i class="fa fa-phone"></i> <?php echo e($cliente->empresario()->first()->telefono); ?></p>
                            <p><i class="fa fa-envelope"></i> <?php echo e($cliente->empresario()->first()->correo); ?></p>
                            <p><i class="fa fa-location-arrow"></i> <?php echo e($cliente->empresario()->first()->municipio); ?></p>
                            <a class="btn btn-block " href="#">Detalles <i class="fa fa-angle-right"></i></a>
                          </div>
                        </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="text-center">
                  <?php echo e($clientes->links()); ?>

                </div>

                
              </div>
              

            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>