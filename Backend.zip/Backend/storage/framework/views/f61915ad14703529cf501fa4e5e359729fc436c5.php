<div id="parallax-one" class="parallax" style="background-image:url(page/images/parallax/bg-02.jpg);">
      <div class="parallax-text-container-1">
        <div class="parallax-text-item">
          <div class="container">
            <div class="row">
              <div class="col-xs-6 col-sm-3">
                <div class="counter-item">
                  <i class="fa fa-users"></i>
                  <div class="timer" id="item1" data-to="200" data-speed="2000"></div>
                  <h5>Empresas Atendidas</h5>
                </div>
              </div>
              <div class="col-xs-6 col-sm-3">
                <div class="counter-item">
                  <i class="fa fa-cubes"></i>
                  <div class="timer" id="item2" data-to="5000" data-speed="2000"></div>
                  <h5>Asesorías Brindadas</h5>
                </div>
              </div>
              <div class="col-xs-6 col-sm-3">
                <div class="counter-item">
                  <i class="fa fa-diamond"></i>
                  <div class="timer" id="item3" data-to="500" data-speed="2000"></div>
                  <h5>Asistencias Técnicas</h5>
                </div>
              </div>
              <div class="col-xs-6 col-sm-3">
                <div class="counter-item">
                  <i class="fa fa-line-chart"></i>
                  <div class="timer" id="item4" data-to="28000" data-speed="2000"></div>
                  <h5>Capital invertido</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
</div>