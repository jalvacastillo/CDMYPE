    <div class="hidden-header"></div>
    <header class="clearfix">

      <div class="top-bar">
        <div class="container">
          <div class="row">
            <div class="col-md-8">
              <ul class="contact-details">
                <li><a href="#"><i class="fa fa-map-marker"></i> Km. 51 1/2 Cantón Agua Zarca, Cabañas, El Salvador</a>
                </li>
                <li><a href="mailto:cdmype.unicaes@gmail.com"><i class="fa fa-envelope-o"></i> cdmype.unicaes@gmail.com</a>
                </li>
                <li><a href="tel:+5032378-1500"><i class="fa fa-phone"></i> 2378-1500 Ext: (136) </a>
                </li>
              </ul>
            </div>
            <div class="col-md-4">
              <ul class="social-list">
                <li>
                  <a class="facebook itl-tooltip" data-placement="bottom" title="Facebook" href="#"><i class="fa fa-facebook"></i></a>
                </li>
                <li>
                  <a class="twitter itl-tooltip" data-placement="bottom" title="Twitter" href="#"><i class="fa fa-twitter"></i></a>
                </li>
                <li>
                  <a class="instagram itl-tooltip" data-placement="bottom" title="Instagram" href="#"><i class="fa fa-instagram"></i></a>
                </li>
                <li>
                  <a class="youtube itl-tooltip" data-placement="bottom" title="youtube" href="#"><i class="fa fa-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div class="navbar navbar-default navbar-top">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="width: 120px;">
              <img alt="" src="assets/images/cdmype-logo.jpg">
            </a>
          </div>
          <div class="navbar-collapse collapse">
            
            <ul class="nav navbar-nav navbar-right">
              <li><a class="<?php echo e(Request::is('/') ? 'active' : ''); ?> hidden-sm" href="<?php echo e(url('/')); ?>">Inicio</a> </li>
              <li><a class="<?php echo e(Request::is('nosotros') ? 'active' : ''); ?>" href="<?php echo e(url('/nosotros')); ?>">Nosotros</a> <li>
              <li><a class="<?php echo e(Request::is('servicios') ? 'active' : ''); ?>" href="<?php echo e(url('/servicios')); ?>">Servicios</a> <li>
              <li><a class="<?php echo e(Request::is('clientes') ? 'active' : ''); ?>" href="<?php echo e(url('/clientes')); ?>">Clientes</a> <li>
              <li><a class="<?php echo e(Request::is('pasantias') ? 'active' : ''); ?>" href="<?php echo e(url('/pasantias')); ?>">Pasantias</a> </li>
              <li><a class="<?php echo e(Request::is('noticias') ? 'active' : ''); ?>" href="<?php echo e(url('/noticias')); ?>">Noticias</a> </li>
              <li><a class="<?php echo e(Request::is('contactos') ? 'active' : ''); ?>" href="<?php echo e(url('/contactos')); ?>">Contactos</a> </li>
            </ul>
          </div>
        </div>
        <ul class="wpb-mobile-menu">
              <li><a class="<?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Inicio</a> </li>
              <li><a class="<?php echo e(Request::is('nosotros') ? 'active' : ''); ?>" href="<?php echo e(url('/nosotros')); ?>">Nosotros</a> <li>
              <li><a class="<?php echo e(Request::is('servicios') ? 'active' : ''); ?>" href="<?php echo e(url('/servicios')); ?>">Servicios</a> <li>
              <li><a class="<?php echo e(Request::is('contactos') ? 'active' : ''); ?>" href="<?php echo e(url('/contactos')); ?>">Contactos</a> </li>
              <li><a class="<?php echo e(Request::is('pasantias') ? 'active' : ''); ?>" href="<?php echo e(url('/pasantias')); ?>">Pasantias</a> </li>
              <li><a class="<?php echo e(Request::is('noticias') ? 'active' : ''); ?>" href="<?php echo e(url('/noticias')); ?>">Noticias</a> </li>
        </ul>
      </div>
    </header>
