<h2 class="classic-title"><span>Our Features</span></h2>

<div class="row">

  <!-- Start Service Icon 1 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-magic icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Photoshop</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 1 -->

  <!-- Start Service Icon 2 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-users icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Web Marketing</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 2 -->

  <!-- Start Service Icon 3 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-globe icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Web Hosting</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 3 -->

  <!-- Start Service Icon 4 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-picture-o icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Phtography</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 4 -->

  <!-- Start Service Icon 5 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-leaf icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Product Design</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 5 -->

  <!-- Start Service Icon 6 -->
  <div class="col-md-6 service-box service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-umbrella icon-medium"></i>
    </div>
    <div class="service-content">
      <h4>Supporting</h4>
      <p>It is a long <strong class="accent-color">established</strong> fact that a reader will be distracted by the readable content of a page.</p>
    </div>
  </div>
  <!-- End Service Icon 6 -->

</div>