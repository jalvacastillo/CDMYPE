<div class="container section">
  <div class="row">
      <!-- Start Recent Posts Carousel -->
    <div class="col-md-12">

      <div class="latest-posts">
        <h4 class="classic-title"><span>Ultimas Noticias</span></h4>
        <div class="latest-posts-classic custom-carousel touch-carousel" data-appeared-items="2">

            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="post-row item">
                <div class="left-meta-post">
                  <div class="post-date"><span class="day"><?php echo e($noticia->created_at->format('d')); ?></span><span class="month"><?php echo e($noticia->created_at->format('M')); ?></span></div>
                    <div class="post-type">
                        <?php if($noticia->categoria == 'Imagen'): ?>
                            <i class="fa fa-picture-o"></i>
                        <?php else: ?>
                            <i class="fa fa-video-camera"></i>
                        <?php endif; ?>
                    </div>
                </div>
                <h3 class="post-title"><a href="#"><?php echo e($noticia->titulo); ?></a></h3>
                <div class="post-content">
                  <p><?php echo e(str_limit($noticia->descripcion, 150,'...')); ?><a class="read-more" href="#">Read More...</a></p>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>

    <br><br>
    </div>
</div>
</div>