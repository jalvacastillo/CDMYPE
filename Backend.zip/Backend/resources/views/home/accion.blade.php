<div class="section purchase">
    <div class="over"></div>
    <div class="container">
        <div class="section-video-content text-center">
            <h1 class="fittext wite-text tlt">
                <span class="texts">
                    <span>Marketing</span>
                    <span>Plan de negocio</span>
                    <span>Productividad</span>
                    <span>Mejora de procesos</span>
                    <span>Control financiero</span>
                    <span>Gestión de Créditos</span>
                </span>
                <br>
            </h1>

            <h3 class="wite-text">Nuestro equipo estará feliz de ayudarte</h3>
            <br>
            <br>
            <a href="{{ url('registro') }}" class="btn-system btn-large btn-wite"><i class="fa fa-tasks"></i> Aplicar</a>
        </div>
    </div>
</div>