
                <div class="col-md-4">

                  <!-- Classic Heading -->
                  <h4 class="classic-title"><span>We Aare Awesome</span></h4>

                  <!-- Accordion -->
                  <div class="panel-group" id="accordion">

                    <!-- Start Accordion 1 -->
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse-one">
                                                    <i class="fa fa-angle-up control-icon"></i>
                                                    <i class="fa fa-desktop"></i> Fully Responsive Theme
                                                </a>
                                            </h4>
                      </div>
                      <div id="collapse-one" class="panel-collapse collapse in">
                        <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ea commodo consequat. Duis aute irure dolor in reprehe in voluptate velit esse cillum dolore fugiat nulla pariatur.</div>
                      </div>
                    </div>
                    <!-- End Accordion 1 -->

                    <!-- Start Accordion 2 -->
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse-tow" class="collapsed">
                                                    <i class="fa fa-angle-up control-icon"></i>
                                                    <i class="fa fa-gift"></i> Touchable Slider
                                                </a>
                                            </h4>
                      </div>
                      <div id="collapse-tow" class="panel-collapse collapse">
                        <div class="panel-body">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. The point of using Lorem Ipsum is that it has a <strong>more-or-less</strong> normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore...</div>
                      </div>
                    </div>
                    <!-- End Accordion 2 -->

                    <!-- Start Accordion 3 -->
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse-three" class="collapsed">
                                                    <i class="fa fa-angle-up control-icon"></i>
                                                    <i class="fa fa-tint"></i> Retina Ready
                                                </a>
                                            </h4>
                      </div>
                      <div id="collapse-three" class="panel-collapse collapse">
                        <div class="panel-body"><strong>Duis</strong> aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore...</div>
                      </div>
                    </div>
                    <!-- End Accordion 3 -->

                  </div>
                  <!-- End Accordion -->

                </div>