<h2 class="classic-title"><span>Requisitos</span></h2>

<div class="row">

  <div class="col-xs-12 service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-3x">1</i>
    </div>
    <div class="service-content">
      <h4>Domicilio</h4>
      <p>La empresa debe estar operando en los municipios de cabañas o cuscatlán.</p>
    </div>
  </div>

  <div class="col-xs-12 service-icon-left-more">
    <div class="service-icon">
      <i class="fa fa-3x">2</i>
    </div>
    <div class="service-content">
      <h4>Ventas</h4>
      <p>La empresa debe de tener ventas anuales mayores a $5,715.</p>
    </div>
  </div>
</div>