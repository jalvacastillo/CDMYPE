<div class="page-banner">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h2>Noticias</h2>
      </div>
      <div class="col-md-6">
        <ul class="breadcrumbs">
          <li><a href="#">Home</a></li>
          <li>Noticias</li>
        </ul>
      </div>
    </div>
  </div>
</div>
