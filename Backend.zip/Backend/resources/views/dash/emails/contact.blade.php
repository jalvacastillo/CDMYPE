<h2>Hola</h2>
<h4>Te ha escrito:</h4>
<hr>
<p><b>Nombre: </b>{{ $msj['nombre'] }}</p>
<p><b>Correo: </b><a href="mailto:{{ $msj['correo'] }}">{{ $msj['correo'] }}</a></p>
<p><b>Mensaje: </b>{{ $msj['mensaje'] }}</p>