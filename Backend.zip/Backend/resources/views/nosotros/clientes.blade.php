          <!-- Start Clients Carousel -->
          <div class="our-clients">

            <!-- Classic Heading -->
            <h4 class="classic-title"><span>Our Happy Clients</span></h4>

            <div class="clients-carousel custom-carousel touch-carousel" data-appeared-items="5">

              <!-- Client 1 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c1.png" alt="" /></a>
              </div>

              <!-- Client 2 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c2.png" alt="" /></a>
              </div>

              <!-- Client 3 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c3.png" alt="" /></a>
              </div>

              <!-- Client 4 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c4.png" alt="" /></a>
              </div>

              <!-- Client 5 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c5.png" alt="" /></a>
              </div>

              <!-- Client 6 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c6.png" alt="" /></a>
              </div>

              <!-- Client 7 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c7.png" alt="" /></a>
              </div>

              <!-- Client 8 -->
              <div class="client-item item">
                <a href="#"><img src="page/images/c8.png" alt="" /></a>
              </div>

            </div>
          </div>