<div class="col-md-4">

  <h4 class="classic-title"><span>Información</span></h4>
  <p>Comunicate con nosotros o visitanos en nuestra oficina</p>
  <div class="hr1" style="margin-bottom:10px;"></div>

  <ul class="icons-list">
    <li><i class="fa fa-map-marker"></i> Km. 51 1/2 Cantón Agua Zarca, Cabañas, El Salvador </li>
    <li><i class="fa fa-envelope-o"></i> <a href="mailto:cdmype.unicaes@gmail.com">cdmype.unicaes@gmail.com</a> </li>
    <li><i class="fa fa-phone"></i> <a href="tel:+50323781500">2378-1500 Ext: (136)</a> </li>
  </ul>
  
  <div class="hr1" style="margin-bottom:15px;"></div>

  <h4 class="classic-title"><span>Horarios de trabajo</span></h4>

  <ul class="list-unstyled">
    <li><strong>Lunes - Viernes</strong> - 8:00 am a 5:00 pm</li>
    <li><strong>Sábados</strong> - 8:00 am a 12:00 md</li>
  </ul>

</div>