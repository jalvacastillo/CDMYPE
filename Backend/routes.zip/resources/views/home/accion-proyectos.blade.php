<div class="section purchase">
    <div class="over"></div>
    <div class="container">
        <div class="section-video-content text-center">
            <h1 class="wite-text">¿Quieres ser Asesor Junior o Consultor? </h1>
            <h1 class="fittext wite-text tlt">
                <span class="texts">
                    <span>Gana experiencia</span>
                    <span>Incrementa tus competencias</span>
                    <span>Da a conocer tu trabajo</span>
                    <span>Obtén ingresos extras</span>
                </span>
                <br>
            </h1>
            <br>
            <br>
            <a href="{{ route('register') }}" class="btn-system btn-large btn-wite">Regístrate <i class="fa fa-arrow-right"></i></a>
        </div>
    </div>
</div>