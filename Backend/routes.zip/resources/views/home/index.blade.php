@extends('layout')

@section('content')

    @include('home.slider')
    @include('home.servicios')
    @include('home.accion')
    @include('home.equipo')
    @include('home.resultados')
    @include('home.noticias')
    @include('home.testimonios')

@endsection