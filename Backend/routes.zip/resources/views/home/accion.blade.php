<div class="section purchase">
    <div class="over"></div>
    <div class="container">
        <div class="section-video-content text-center">
            <h1 class="wite-text">Te ayudamos con </h1>
            <h1 class="fittext wite-text tlt">
                <span class="texts">
                    <span>Marketing Digital</span>
                    <span>Planes de negocio</span>
                    <span>Mejora de procesos</span>
                    <span>Gestión de Créditos</span>
                </span>
                <br>
            </h1>
            <br>
            <br>
            <a href="{{ route('registroCliente') }}" class="btn-system btn-large btn-wite">Haz tu diagnostico <i class="fa fa-arrow-right"></i></a>
        </div>
    </div>
</div>